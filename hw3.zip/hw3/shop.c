#include "game.h"


Shop* loadShop()
{

    FILE* fp = fopen("Items.txt","r");
    if(fp == NULL)
    {
	printf("\nError, could not open item file.");
	return NULL;
    }
    Shield* startShield = NULL;
    Sword*  startSword	= NULL;
    Shield* current	     = NULL;
    Shield* new		 = NULL;
    Shield* previous     = NULL;

    Sword* currentSword  = NULL;
    Sword* newSword	     = NULL;
    Sword* previousSword = NULL;

    int i;
    for(i = 0; i < NUMSHIELDS ; i++)
    {
	new = (Shield*)malloc(sizeof(Shield));
	if(new != NULL)
	{
	    ParseShieldInfo(new, fp);
	    new->prevShield = NULL;
	    new->nextShield = NULL;
	    current = startShield;
	    while(current != NULL)
	    {
		previous = current;
		current = current->nextShield;
	    }
	    if(previous == NULL)
	    {
		startShield = new;
	    }
	    else
	    {
		previous->nextShield = new; 
		new->prevShield = previous;
		new->nextShield = current;
	    }
	}
	else
	{
	    printf("\nError, not enough memory for new shield. Malloc failed.");
	    return NULL;
	}
    }	    

    for(i = 0 ; i < NUMSWORDS ; i++)
    {
	newSword = (Sword*)malloc(sizeof(Sword));
	if(newSword != NULL)
	{
	    ParseSwordInfo(newSword, fp);
	    newSword->nextSword = NULL;
	    newSword->prevSword = NULL;
	    currentSword = startSword;
	    while(currentSword != NULL)
	    {
		previousSword = currentSword;
		currentSword = currentSword->nextSword;
	    }
	    if(previousSword == NULL)
	    {
		startSword = newSword;
	    }
	    else
	    {
		previousSword->nextSword = newSword;
		newSword->prevSword = previousSword; 
		newSword->nextSword = currentSword; 
	    }
	}
	else
	{
	    printf("\nCould not find space for sword list. Malloc failed");
	    return NULL;
	}
    }

    Shop* shopStock;
    shopStock = malloc(sizeof(Shop));

    if(shopStock != NULL)
    {
	shopStock->headShield = startShield; 
	shopStock->headSword = startSword;  
    }
    else
    {
	printf("\nInsufficent memory for malloc.");
	return NULL;
    }
    fclose(fp);
    return shopStock;
}	



void destroyShop(Shop* shop)
{

    Sword* swords;
    swords = shop->headSword;
    Sword* tempSword;
    while(swords != NULL)
    {
	tempSword = swords;		
	swords = swords->nextSword;	    
	free(tempSword);		
    }


    Shield* shields;
    shields = shop->headShield; 
    Shield* tempShield;
    while(shields != NULL)
    {
	tempShield = shields;		    
	shields = shields->nextShield;	
	free(tempShield);		    
    }
    free(shop);
}


void sortShields(Shield** shields)
{
    Shield* currentShield;
    Shield* moveShield;
    Shield* rightLink;
    Shield* leftLink;
    currentShield = *shields;

    int i;
    for(i = 0; i < NUMSHIELDS ; i++)
    {
	currentShield = *shields;
	while(currentShield != NULL && currentShield->nextShield != NULL && currentShield->cost < currentShield->nextShield->cost)
	{
	    currentShield = currentShield->nextShield;
	}
	if(currentShield != NULL && currentShield->nextShield != NULL)
	{
	    moveShield = currentShield->nextShield;  
	    leftLink = moveShield->prevShield;
	    rightLink = moveShield->nextShield;
	    int cost;
	    cost = moveShield->cost; 
	    currentShield = *shields;
	    if(cost < currentShield->cost) 
	    {
		moveShield->prevShield = NULL;		
		moveShield->nextShield = currentShield;     
		currentShield->prevShield = moveShield;	
		*shields = moveShield;			

		leftLink->nextShield = rightLink;		
		rightLink->prevShield = leftLink;
	    }
	    else
	    {

		Shield* holdShield;
		while(currentShield != NULL && cost > currentShield->cost)
		{
		    holdShield = currentShield;
		    currentShield = currentShield->nextShield;
		}
		if(currentShield != NULL)
		{
		    moveShield->nextShield = currentShield; 
		    moveShield->prevShield = holdShield;	
		    holdShield->nextShield = moveShield;    
		    currentShield->prevShield = moveShield; 
		    leftLink->nextShield = rightLink;
		    if(rightLink == NULL)
		    {
			return;
		    }
		    else
		    {
			rightLink->prevShield = leftLink;
		    }
		}
	    }

	}
	else
	{
	    return;
	}
    }
    return;
}

void sortSwords(Sword** swords)
{
    Sword* currentSword;
    Sword* moveSword;
    Sword* rightLink;
    Sword* leftLink;
    currentSword = *swords;

    int i;
    for(i = 0; i < NUMSWORDS ; i++)
    {
	currentSword = *swords;
	while(currentSword != NULL && currentSword->nextSword != NULL && currentSword->cost < currentSword->nextSword->cost)
	{
	    currentSword = currentSword->nextSword;
	}
	if(currentSword != NULL && currentSword->nextSword != NULL)
	{
	    moveSword = currentSword->nextSword;  
	    leftLink = moveSword->prevSword;
	    rightLink = moveSword->nextSword;
	    int cost;
	    cost = moveSword->cost; 
	    currentSword = *swords;
	    if(cost < currentSword->cost)
	    {
		moveSword->prevSword = NULL;		
		moveSword->nextSword = currentSword;       
		currentSword->prevSword = moveSword;	
		*swords = moveSword;			
		leftLink->nextSword = rightLink;		
		rightLink->prevSword = leftLink;
	    }
	    else
	    {
		Sword* holdSword;
		while(currentSword != NULL && cost > currentSword->cost)
		{
		    holdSword = currentSword;
		    currentSword = currentSword->nextSword;
		}
		if(currentSword != NULL)
		{
		    moveSword->nextSword = currentSword; 
		    moveSword->prevSword = holdSword;   
		    holdSword->nextSword = moveSword;	
		    currentSword->prevSword = moveSword;
		    leftLink->nextSword = rightLink;
		    if(rightLink == NULL)
		    {
			return;
		    }
		    else
		    {
			rightLink->prevSword = leftLink;
		    }

		}
	    }

	}
	else
	{
	    return;
	}
    }
    return;
}

void printShields(Shield* shields)
{
    Shield* start;
    start = shields;
    int i = 1;
    while(shields != NULL)
    {
	printf("%d - %s\n\t Cost: %d\n\t Defense: %d\n",i,shields->name, shields->cost, shields->defense);
	printf("%s\n\n", shields->description);
	shields = shields->nextShield;
	i++;
    }
    shields = start;
}

void printSwords(Sword* swords)
{
    Sword* start;
    start = swords;
    int i = 1;
    while(swords != NULL)
    {
	printf("%d - %s\n\t Cost: %d\n\t Attack: %d\n",i,swords->name,swords->cost,swords->attack);
	printf("%s\n\n", swords->description);
	swords = swords->nextSword;
	i++;
    }
    swords = start;
}

Sword* removeSwordFromList(Sword** swords, int choice)
{
    Sword* holdSword;
    Sword* currentSword;
    currentSword = *swords;
    int size = 0;
    while(currentSword != NULL)
    {
	currentSword = currentSword->nextSword;
	size++;
    }
    while(size < choice || choice < 1)
    {
	printf("\nInvalid choice. Please choose again.\n> ");
	scanf("%d",&choice);	
    }
    currentSword = *swords;
    if(choice == 1)
    {
	holdSword = currentSword;
	currentSword = currentSword->nextSword;


	holdSword->nextSword = NULL; 
	currentSword->prevSword = NULL;
	*swords = currentSword;
	return holdSword;
    }
    else 
    {
	int i = 0;
	for(i = 0; i < choice - 1; i++)
	{
	    holdSword = currentSword;
	    currentSword = currentSword->nextSword;
	}
	if(currentSword->nextSword != NULL)
	{
	    holdSword->nextSword = currentSword->nextSword; 
	    currentSword->nextSword->prevSword = holdSword; 
	}
	else
	{
	    holdSword->nextSword	= NULL;	    
	    currentSword->prevSword = NULL;
	}
    }
    return currentSword;
}

Shield* removeShieldFromList(Shield** shields, int choice)
{
    Shield* holdShield;
    Shield* currentShield;
    currentShield = *shields;
    int size = 0;
    while(currentShield != NULL)
    {
	currentShield = currentShield->nextShield;
	size++;
    }
    while(size < choice || choice < 1)
    {
	printf("\nInvalid choice. Please choose again.\n> ");
	scanf("%d",&choice);	
    }
    currentShield = *shields;
    if(choice == 1)
    {
	holdShield = currentShield;
	currentShield = currentShield->nextShield;
	holdShield->nextShield = NULL; 
	currentShield->prevShield = NULL;
	*shields = currentShield;
	return holdShield;
    }
    else
    {
	int i = 0;
	for(i = 0; i < choice - 1; i++)
	{
	    holdShield = currentShield;
	    currentShield = currentShield->nextShield;
	}
	if(currentShield->nextShield != NULL)
	{
	    holdShield->nextShield = currentShield->nextShield; 
	    currentShield->nextShield->prevShield = holdShield;
	}
	else
	{
	    holdShield->nextShield = NULL;	    
	    currentShield->prevShield = NULL;	
	}
    }
    return currentShield;
}

void freeHeroesAndItems(Hero* heroes)
{
    int i;
    for(i = 0; i < NUMCHOSENHEROES; i++)
    {
	if(heroes[i].heroSword != NULL)
	{
	    free(heroes[i].heroSword);
	}
	if(heroes[i].heroShield != NULL)
	{
	    free(heroes[i].heroShield);
	}
    }
    free(heroes);
}

void goShopping(Hero* heroes, Shop* shop)
{


    sortShields(&(shop->headShield));
    sortSwords(&(shop->headSword));

    printf("\n\nNow, you will select a sword and shield for your heroes.\n");

    int firstPass = 1; 

    int bank = STARTINGBANKVALUE;

    int shieldsBought = 0;
    int swordsBought = 0; 

    while(1)
    {
	printf("Which would you like to look at?\n");
	printf("1: Swords\n2: Shields\n3: Continue to fight\n");
	printf("> ");
	int choice; 
	scanf("%d", &choice);
	while(choice < 1 || choice > 3)
	{
	    printf("Invalid choice. Select again: \n");
	    printf("> ");
	    scanf("%d", &choice);
	}

	if(choice == 3)
	{
	    if(firstPass == 1)
	    {
		printf("Are you sure you don't want to buy anything?\n");
		printf("1: yes\n2: no\n");
		printf("> ");
		scanf("%d", &choice);
		while(choice < 1 || choice > 2)
		{
		    printf("Invalid choice. Select again: \n");
		    printf("> ");
		    scanf("%d", &choice);
		}
	    }
	    else
	    {
		choice = 1;
	    }

	    if(choice == 1)
	    {
		destroyShop(shop);
		return;
	    }
	}
	else if(choice == 2)
	{	


	    while(1)
	    {
		printShields(shop->headShield);

		while(1)
		{
		    printf("\nBudget: %d\n", bank);
		    printf("Select a shield (-1 to go back): \n");
		    printf("> ");
		    scanf("%d", &choice);

		    while((choice < 1 || choice > NUMSHIELDS - shieldsBought) && choice != -1)
		    {
			printf("Invalid choice. Select again: \n");
			printf("> ");
			scanf("%d", &choice);
		    }

		    if(choice != -1)
		    {
			if(findShieldPrice(shop->headShield, choice) > bank)
			{
			    printf("You don't have enough money for that!\n");
			}
			else break;
		    }
		    else break;
		}

		if(choice == -1)
		{
		    break;
		}
		else
		{
		    int heroChoice; 

		    while(1)
		    {
			printHeroes(heroes, NUMCHOSENHEROES);
			printf("Which hero do you want to have the item? (-1 to go back): \n");
			printf("> ");
			scanf("%d", &heroChoice);

			while((heroChoice < 1 || heroChoice > NUMCHOSENHEROES) && heroChoice != -1)
			{
			    printf("Invalid choice. Select again: \n");
			    printf("> ");
			    scanf("%d", &heroChoice);
			}

			if(heroChoice == -1)
			{
			    break;
			}

			if(heroes[heroChoice - 1].heroShield != NULL)
			{
			    printf("That hero already has a shield. Choose again.\n");
			}
			else
			{
			    break;
			}

		    }


		    if(heroChoice == -1)
		    {
			break;
		    }
		    else
		    {
			Shield* item = removeShieldFromList(&(shop->headShield), choice);
			heroes[heroChoice - 1].heroShield = item;
			bank -= item->cost;
			shieldsBought++;
			firstPass = 0;
		    }
		}
	    }
	}
	else if(choice == 1)
	{

	    while(1)
	    {
		printSwords(shop->headSword);

		while(1)
		{
		    printf("\nBudget: %d\n", bank);
		    printf("Select a sword (-1 to go back): \n");
		    printf("> ");
		    scanf("%d", &choice);

		    while((choice < 1 || choice > NUMSWORDS - swordsBought) && choice != -1)
		    {
			printf("Invalid choice. Select again: \n");
			printf("> ");
			scanf("%d", &choice);
		    }

		    if(choice != -1)
		    {
			if(findSwordPrice(shop->headSword, choice) > bank)
			{
			    printf("You don't have enough money for that!\n");
			}
			else break;
		    }
		    else break;
		}

		if(choice == -1)
		{
		    break;
		}
		else
		{
		    int heroChoice; 

		    while(1)
		    {
			printHeroes(heroes, NUMCHOSENHEROES);
			printf("Which hero do you want to have the item? (-1 to go back): \n");
			printf("> ");
			scanf("%d", &heroChoice);

			while((heroChoice < 1 || heroChoice > NUMCHOSENHEROES) && heroChoice != -1)
			{
			    printf("Invalid choice. Select again: \n");
			    printf("> ");
			    scanf("%d", &heroChoice);
			}

			if(heroChoice == -1)
			{
			    break;
			}

			if(heroes[heroChoice - 1].heroSword != NULL)
			{
			    printf("That hero already has a sword. Choose again.\n");
			}
			else
			{
			    break;
			}
		    }
		    if(heroChoice == -1)
		    {
			break;
		    }
		    else
		    {
			Sword* item = removeSwordFromList(&(shop->headSword), choice);
			heroes[heroChoice - 1].heroSword = item;
			bank -= item->cost;
			swordsBought++;
			firstPass = 0;
		    }
		}
	    }
	}
    }
}

int findSwordPrice(Sword* swords, int choice)
{
    int i = 1;
    while(i < choice)
    {
	swords = swords->nextSword;
	i++;
    }
    return swords->cost;
}

int findShieldPrice(Shield* shields, int choice)
{
    int i = 1;
    while(i < choice)
    {
	shields = shields->nextShield;
	i++;
    }
    return shields->cost;
}

