#include "game.h"
#include<stdlib.h>
#include<stdio.h>
Boss* loadBoss()// This function may be a seg fault 
{
    Boss* Boss=malloc(sizeof(Boss));
    FILE* fp=fopen("Boss.txt","r");
    if(fp==NULL)
    {
	printf("File failed to load");
	return 0;
    }
    //printf("we in load boss\n");
    fscanf(fp,"%s | %d | %d | %d | %d",Boss->name,&Boss->health,&Boss->baseDefense,&Boss->baseAttack,&Boss->baseSpeed);
    Boss->maxHealth=Boss->health;
    int numChoices;
    int count=0;
    int temp1;
    int temp2;
    int temp3;
    DecisionTreeNode* root=malloc(sizeof(DecisionTreeNode));

    while(!feof(fp))
    {
	DecisionTreeNode* newNode=malloc(sizeof(DecisionTreeNode));
	ActionNode* head=malloc(sizeof(ActionNode));
	fscanf(fp,"%d|%d|%d",&temp1,&temp2,&numChoices);
	newNode->healthFloor=temp1;
	newNode->healthCeiling=temp2;
	    for(count=0;count<numChoices;count++)
	    {
		ActionNode* CurAction=malloc(sizeof(ActionNode));
		fscanf(fp,"%d",&temp3);
		CurAction->decision=temp3;

		head=addActionToList(head,CurAction);
	    }
	newNode->FirstAction=head;
	root=addNodeToTree(root,newNode);
    }
    Boss->root=root;
    fclose(fp);
    return Boss;
}

ActionNode* addActionToList(ActionNode* front, ActionNode* newAction)// this function seg faults probably whenever I am defining the cur=cur->next
{
    //printf("We in addactiontolist\n");
    ActionNode* cur=malloc(sizeof(ActionNode));
    cur=front;
    while(cur->next!=NULL)
    {
	cur=cur->next;
    }
    cur->next=newAction;
    newAction->next=NULL;


return front;

}

DecisionTreeNode* addNodeToTree(DecisionTreeNode* root, DecisionTreeNode* newNode)
{
   // printf("we in addnodetotree\n");
    if(root==NULL)
    {
	root=newNode;
	root->left=NULL;
	root->right=NULL;
    }
    else if(newNode->healthCeiling<root->healthCeiling)
    {
	root->left=addNodeToTree(root->left,newNode);
    }
    else if(newNode->healthCeiling> root->healthCeiling)
    {
	root->right=addNodeToTree(root->right,newNode);
    }

return root;

}

ActionNode* fetchNewList(Boss* boss, DecisionTreeNode* root)
{
   // printf("we in fetch\n");
    if(root==NULL)
    {
	return NULL;
    }
    if(boss->health >= root->healthFloor && boss->health <= root->healthCeiling)
    {
	return root->FirstAction;
    }
    if(boss->health<root->healthFloor)
    {
	if(root->left!=NULL)
	{
	    return(fetchNewList(boss,root->left));
	}
	else if(boss->health > root->healthCeiling)
	{
	    if(root->right!=NULL)
	    {
		return(fetchNewList(boss,root->right));
	    }
	}
    }
    return NULL;
}

void freeBossTree(DecisionTreeNode* root)
{
   // printf("freeBoss\n");
    if(root==NULL)
    return;
    freeBossTree(root->left);
    freeBossTree(root->right);
    freeActionListInNode(root->FirstAction);
    free(root);

}

void freeActionListInNode(ActionNode* head)
{
    //printf("freeaction\n");
    ActionNode* curr;

    curr=head;
    while(curr->next!=NULL)
    {
	curr=curr->next;
	free(curr);
    }

}

