
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#define NUMHEROES 6
#define NUMCHOSENHEROES 3
#define MAXNUMSAVEFILES 5
#define MAXPLAYERNAME 20
#define NUMSWORDS 10
#define NUMSHIELDS 8
#define STARTINGBANKVALUE 13000
#define MAXFILELINELENGTH 150 
typedef enum b_
{
	false,
	true
} bool;
typedef enum f_
{
	EXIST,
	DOESNOTEXIST
} FileFinder;

typedef enum a_
{
	ATTACK,
	DEFEND,
	HEAL
} Decision;
typedef struct shield_
{
	char name[50];
	int cost;
	int defense;
	char description[100];
	struct shield_* nextShield;
	struct shield_* prevShield;
} Shield;

typedef struct sword_
{
	char name[50];
	int cost;
	int attack;
	char description[100];
	struct sword_* nextSword;
	struct sword_* prevSword;
} Sword;

typedef struct hero_
{
	char name[40];
	Sword* heroSword;
	Shield* heroShield;
	Decision decision;
	int health;
	int maxHealth;
	bool hasHealed;
	int baseDefense;
	int baseAttack;
	int baseSpeed;
} Hero;
typedef struct aNode_
{
	Decision decision;
	struct aNode_* next;
} ActionNode;
typedef struct dTree_
{
	int healthFloor;
	int healthCeiling;
	struct dTree_* left;
	struct dTree_* right;
	ActionNode* FirstAction;
} DecisionTreeNode;
typedef struct boss_
{
	char name[40];
	int health;
	int maxHealth;
	int baseDefense;
	int baseAttack;
	int baseSpeed;
	DecisionTreeNode* root;
} Boss;

typedef struct shop_
{
	Sword* headSword;
	Shield* headShield;
} Shop;


void deleteFile(int choice, char* filename);
void saveFileData(int choice, char* filename, Hero* heroes, char* playerName, int progress);
char* getPlayerName();
Hero* loadSavedData(char* filename, int haveItems);
Hero* loadInitialData();
Hero* pickHeroes(Hero* heroes);
void sortHeroes(Hero* heroes);
void printHeroes(Hero* heroes, int numHeroes);

FileFinder findSaveFile();
void loadSavedGameHandler();
void DeleteSavedGameHandler();
void loadGameStateData(char*** names, int** states, int* fileCount);
char* choiceToFile(int num);
void freeMemory(char** names, int* states);
void startNewGame();
void playGame(Hero* heroes, char* playerName, Boss* boss, int progress, int choice);
int chooseSaveFile();


Shop* loadShop();
void destroyShop(Shop* shop);
void goShopping(Hero* heroes, Shop* shop);

void printShields(Shield* shields);
void printSwords(Sword* swords);

Sword* removeSwordFromList(Sword** swords, int choice);
Shield* removeShieldFromList(Shield** shields, int choice);

void freeHeroesAndItems(Hero* heroes);

void sortShields(Shield**);
void sortSwords(Sword**);

int findSwordPrice(Sword*, int);
int findShieldPrice(Shield*, int);

Boss* loadBoss();
ActionNode* addActionToList(ActionNode*, ActionNode*);
DecisionTreeNode* addNodeToTree(DecisionTreeNode*, DecisionTreeNode*);
ActionNode* fetchNewList(Boss*, DecisionTreeNode*);
void freeBossTree(DecisionTreeNode*);
void freeActionListInNode(ActionNode*);

void sort(Hero*);

int fight(Boss*, Hero*);
void getHeroDecisions(Hero*);
void printFightStatus(Boss*, Hero*);
void handleBossAction(Boss*, Hero*, Decision, int*);
void handleHeroAction(Hero*, Boss*, Decision);

void ParseShieldInfo(Shield*, FILE*);
void ParseSwordInfo(Sword*, FILE*); 



int debugPrint(Hero*);
