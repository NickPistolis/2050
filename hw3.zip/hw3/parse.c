#include "game.h"
void ParseShieldInfo(Shield* s, FILE* fp)//I think in theory this function should work, but for some reason it does not work. Ive been messing around with print statements, but could not find a way to make the function work. Same problem for Swords.
{
	//printf("Parse Sh\n");
        char buffer[256];
	char* token=strtok(buffer,"\r\n\t|");
	int count=0;
	while(token!=NULL)
	{
	    if(count==0)
	    strcpy(s->name,token);
	    else if(count==1)
	    {
	    s->cost=atoi(token);
	    printf("cost %d\n",atoi(token));
	    }
	    else if(count==2)
	    {
	    s->defense=atoi(token);
	    printf("stat %d\n",atoi(token));
	    }
	    else if(count==3)
	    strcpy(s->description,token);
	    token=strtok(NULL,"\r\n\t|");
	    count++;
	}
}

void ParseSwordInfo(Sword* s, FILE* fp)
{
   // printf("Parse sw\n");
    char buffer[256];
	char* token=strtok(buffer,"\r\n\t|");
	int count=0;
	while(token!=NULL)
	{
	    if(count==0)
	    strcpy(s->name,token);
	    else if(count==1)
	    s->cost=atoi(token);
	    else if(count==2)
	    s->attack=atoi(token);
	    else if(count==3)
	    strcpy(s->description,token);
	    token=strtok(NULL,"\r\n\t|");
	    count++;
	}
}
/*
int isDec(char* words)
{   int numCaps;
    int numSpaces;
    int count=0;
    int length=strlen(words);
  if(words[length]=='.' || words[length]=='!')
    return 1;
  for(count=0;count<length;count++)
    {
	if(isupper(words[count]!=0))
	numCaps++;
    }
  for(count=0;count<length;count++)
    {
	if(isspace(words[count]!=0))
	numSpaces++;
    }
   if(numCaps==1 && numSpaces>3)
    return 1;
  else 
    return 0;

}
int isCost(char* words)
{
    int count;
    int tracker;
    int length=strlen(words);
    for(count=0;count<length;count++)
    {
	if(isdigit(words[count]!=0))
	tracker++;

    }
    if(tracker>2)
	return 1;
    else 
    return 0;
}
int isStat(char* words)
{
    int count;
    int tracker;
    int length=strlen(words);
    for(count=0;count<length;count++)
    {
	if(isdigit(words[count]!=0))
	tracker++;

    }
    if(tracker<3 && tracker==length)
	return 1;
    else 
    return 0;
}
*/
