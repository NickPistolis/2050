#include"game.h" 
int fight(Boss* boss, Hero* heroes)
{

    Hero* h = malloc(sizeof(Hero)*(NUMCHOSENHEROES+1));
    int i;
    for(i = 0; i < NUMCHOSENHEROES; i++)
    {
	h[i] = heroes[i];
	h[i].hasHealed = false;
	h[i].maxHealth = h[i].health;
    }
    h[NUMCHOSENHEROES].health = -1;
    h[NUMCHOSENHEROES].baseSpeed = boss->baseSpeed;
    strcpy(h[NUMCHOSENHEROES].name, boss->name);    
    sort(h);
    bool allHeroesDead = false;
    ActionNode* currentList = NULL;
    while(1)
    {
	printFightStatus(boss, heroes); 
	getHeroDecisions(h);
	if(allHeroesDead == true)
	{
	    return 1;
	}
	printf("***********EVENTS***********\n");
	allHeroesDead = true;
	if(currentList == NULL)
	{
	    currentList = fetchNewList(boss, boss->root);
	}
	for(i = 0; i < NUMCHOSENHEROES + 1; i++)
	{
	    if(strcmp(h[i].name, boss->name) == 0)
	    {
		if(boss->health == 0)
		{
		    return 0;
		}
		else
		{

		    int place;
		    handleBossAction(boss, h, currentList->decision, &place);
		    int d;
		    for(d = 0; d < NUMCHOSENHEROES; d++)
		    {
			if(strcmp(h[place].name, heroes[d].name) == 0) 
			{
			    heroes[d].health = h[place].health;
			    break;
			}
			if((d == i - 1) && heroes[d].health == 0)
			{
			    allHeroesDead = true;
			}

		    }
		}
	    }
	    else
	    {

		if(h[i].health == 0) 
		    continue;
		else
		{
		    allHeroesDead = false;
		    handleHeroAction(&h[i], boss, currentList->decision);
		    int d;
		    for(d = 0; d < NUMCHOSENHEROES; d++)
		    {
			if(strcmp(h[i].name, heroes[d].name) == 0) 
			{
			    heroes[d].health = h[i].health;
			    break;
			}
		    }

		}
	    }
	}
	currentList = currentList->next;
	printf("************************************\n\n");
    }
}


int debugPrint(Hero* h)
{
    int i;
    for(i = 0; i < NUMCHOSENHEROES + 1; i++)
    {
	printf("%s -> ", h[i].name);
    }
    printf("\n");
    return 0;
}


void getHeroDecisions(Hero* heroes)
{
    int i;
    int choice;

    printf("1: Attack\n2: Defend\n3: Heal\n");
    for(i = 0; i < NUMCHOSENHEROES + 1; i++)
    {

	if(heroes[i].health > 0)
	{
	    printf("Acting in position %d: %s.\n", i+1, heroes[i].name); 
	    printf("Choose your action for %s:\n>", heroes[i].name);
	    scanf("%d", &choice);
	    while(choice < 1 || choice > 3)
	    {
		printf("Incorrect option. Choose again: ");
		scanf("%d", &choice);
	    }
	    heroes[i].decision = choice - 1;
	}
    }
}

void printFightStatus(Boss* boss, Hero* heroes)
{
    printf("\n\n***************THE BATTLEFIELD*************\n\n");
    printf("%-40s\nHealth: %d\n\n", heroes[0].name, heroes[0].health);
    printf("%-20s\t\t\t%-10s\nHealth: %d\t\t\t\tHealth: %d\n\n", heroes[1].name,	
	    boss->name, heroes[1].health, boss->health);
    printf("%-40s\nHealth: %d\n\n", heroes[2].name, heroes[2].health);
    printf("***************************************************\n\n");
}

void handleBossAction(Boss* boss, Hero* heroes, Decision d, int* place)
{
    switch(d)
    {
	case HEAL:
	    printf("%s has been healed ", boss->name);
	    int x = rand()%200 + 75;
	    if(boss->health + x >= boss->maxHealth)
	    {
		printf("to full health!\n");
		boss->health = boss->maxHealth;
	    }
	    else
	    {
		printf("for %dhp!\n", x);
		boss->health += x;
	    }
	    break;
	case ATTACK:
	    printf("%s attacks! ", boss->name);
	    while(1)
	    {
		x = rand()%NUMCHOSENHEROES;
		int i;
		for(i = 0; i <= x; i++)
		{
		    if(strcmp(heroes[i].name, boss->name) == 0) break;
		}
		if(i != x + 1)
		{
		    x += 1;
		}

		if(heroes[x].health != 0) break;
	    }
	    *place = x;

	    int dmg; 
	    int t = 0;
	    if(heroes[x].decision != DEFEND) t = 1;  
	    if(heroes[x].heroShield != NULL)
		dmg = boss->baseAttack - rand()%heroes[x].heroShield->defense - rand()%heroes[x].baseDefense + (t*rand()%heroes[x].baseDefense);
	    else
		dmg = boss->baseAttack - rand()%heroes[x].baseDefense + (t*rand()%heroes[x].baseDefense);
	    if(dmg < 0) dmg = 0;
	    printf("%s takes %d damage.\n", heroes[x].name, dmg);
	    heroes[x].health -= dmg;
	    if(heroes[x].health < 0) heroes[x].health = 0;
	    break;
	case DEFEND:	
	    printf("%s is defending.\n", boss->name);
    }
}

void handleHeroAction(Hero* hero, Boss* boss, Decision decision)
{
    switch(hero->decision)
    {
	case HEAL:
	    if(hero->hasHealed)
	    {
		int x = rand()%100 + 50;
		if(hero->health + x >= hero->maxHealth)
		{
		    printf("%s has been healed to full health!\n", hero->name);
		    hero->health = hero->maxHealth;
		}
		else
		{
		    printf("%s has been healed for %dhp!\n", hero->name, x);
		    hero->health += x;
		}
	    }
	    else
	    {
		hero->hasHealed = true;
		printf("%s's exilir has been used, healing to full health!\n", hero->name);
		hero->health = hero->maxHealth;
	    }
	    break;
	case ATTACK:
	    printf("%s attacks! ", hero->name);
	    int x;
	    int t = 0;
	    if(decision != DEFEND) t = 1;
	    if(hero->heroSword != NULL)
		x = hero->baseAttack + rand()%hero->heroSword->attack - rand()%boss->baseDefense
		    + (t*rand()%boss->baseDefense);
	    else
		x = hero->baseAttack - rand()%boss->baseDefense + (t*rand()%boss->baseDefense);
	    if(x < 0) x = 0;
	    printf("%s takes %d damage.\n", boss->name, x);
	    boss->health -= x;
	    if(boss->health < 0) boss->health = 0;
	    break;
	case DEFEND:	
	    printf("%s is defending.\n", hero->name);
	    break;
	default:
	    printf("What?\n");

    }
}
void sort(Hero* heroes)
{
    int i, j;
    for(i = 0; i < NUMCHOSENHEROES + 1; i++)
    {
	for(j = 0; j < NUMCHOSENHEROES + 1; j++)
	{
	    if(heroes[j].baseSpeed > heroes[j-1].baseSpeed)
	    {
		Hero temp = heroes[j];
		heroes[j] = heroes[j-1];
		heroes[j-1] = temp;
	    }
	}
    }
}

